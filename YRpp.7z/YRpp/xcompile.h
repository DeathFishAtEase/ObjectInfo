#ifndef XCOMPILE_H_
#define XCOMPILE_H_

#ifdef __GNUC__
#include <gcc.h>
#endif

#include <Compiler Specifics/hashmap.h>

#endif
