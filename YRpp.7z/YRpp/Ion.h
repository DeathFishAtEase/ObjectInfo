/*
	This handles the LightningStorm, PsychicDominator and the ChronoScreenEffect.
	Used to handle IonStorms in TS.

	Completely Static.
*/

#pragma once

// === COMPLETELY STATIC CLASS === dunno yet how to define...

class Ion
{
public:
	//LightningStorm


	//PsychicDominator


	//ChronoScreenEffect
};
