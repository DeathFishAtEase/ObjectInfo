/*******************************************************************
				C&C Yuri's Revenge 1.001 C++ Wrapper
				====================================
				   (c) 2007-2010 by pd and DCoder

*******************************************************************/

#pragma once

#include <YRPPCore.h>
#include <FileSystem.h>
#include <StringTable.h>
#include <MessageBox.h>
#include <Drawing.h>
#include <PCX.h>
#include <CommandClass.h>
#include <GameClasses.h>
#include <SwizzleManagerClass.h>
